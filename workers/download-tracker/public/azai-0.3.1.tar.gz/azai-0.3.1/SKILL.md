---
name: AZAI
description: Use when calling AZAI hosted /v1 or installing the local true-AI package. Dual surface: Worker /v1 + catalog MCP. This Worker /v1/mesh/* PROXY to aziel-runtime via AZIEL_RUNTIME. Suite mesh default OFF. QNM-BUILD-1.0 live|locked|isolated. QNS-CD-1.0 hub cite (photon QNS1 packet transfer; qnm-node local qnsd; aziel-runtime cites). No Node Gate. No public qnsd proxy. No auto-heal. Not anonymity. Not a Softwares-tab product. Ask Jeeves research assistant for the public Corpus/Library. Author Aziel Eliab.
---

# AZAI

AZAI packages a **true local AI** stack on an **Ollama** base with **JEEVES**.
OpenAI-compatible local API. Not a hosted paid-key proxy. Author: **Aziel Eliab**.

**THIS IS:** true local AI. Ollama is the local model base. JEEVES is the
ethics/assistant layer inside the shell (**Ask Jeeves** research assistant).
JEEVES is not sovereign — Lamb Lens first; public Corpus posture; never the
operator.

**THIS IS NOT:** a new foundation model, a kernel, a worm, IP-blocking malware,
a VPN, a hosted paid-key proxy, GPT, or a sovereign agent.

Always send `User-Agent: Mozilla/5.0`. Cloudflare Workers may 403 an empty agent.

## Call these URLs

- Worker OpenAPI: https://azai-download-tracker.vibelock.workers.dev/openapi.json
- Catalog OpenAPI: https://aziel-runtime.vibelock.workers.dev/openapi.json
- MCP: `POST https://aziel-runtime.vibelock.workers.dev/mcp`
- Live skill (this markdown): `GET https://azai-download-tracker.vibelock.workers.dev/v1/skill`
- Suite mesh: `GET https://azai-download-tracker.vibelock.workers.dev/v1/mesh` (PROXY; default OFF; QNS-CD-1.0 cite)

Ops (do **not** increment downloads or views):

- `GET /v1/health` — liveness
- `GET /v1/skill` — this file
- `GET /v1/jeeves` — Ask Jeeves research-assistant contract (not chat)
- `GET /v1/mesh` — PROXY suite mesh status. Default OFF. QNM live|locked|isolated. QNS-CD-1.0 hub cite on the payload. Never enables. Not a public qnsd proxy.
- `GET /v1/mesh/nodes` — PROXY Live Nodes roster (5-minute presence). Same QNS-CD-1.0 cross-map stamp.
- `POST /v1/mesh/{enable,disable,join,heartbeat,leave,broadcast}` — PROXY. Bearer required to enable. No auto-heal. Anon-broadcast is not a publish path. No qnsd.
- Product POSTs listed in OpenAPI

Hosted `/v1` is **lamb-check ONLY**. It does not run Ollama and does not
spend paid keys. Jeeves chat runs on local `azai serve`.

Public engines accept ChatGPT (GPT Actions / OpenAI), Grok (xAI), Venice, Claude (Anthropic), Cursor (MCP), Glama (MCP), Perplexity, Microsoft Copilot / Bing, Google Gemini / Vertex, Mistral, Meta AI, Apple Intelligence surfaces, Amazon Q tooling, DuckAssist, You.com, Cohere, and other MCP/OpenAPI-capable assistants. ChatGPT: GPT Actions. Grok: import OpenAPI as a custom tool. Venice: HTTP tools. Claude, Cursor, Glama, and other MCP clients: catalog MCP.

## Ask Jeeves (Corpus / Library research assistant)

**Ask Jeeves** is the documented research-assistant mode of JEEVES for site
assistants, especially https://www.azielcorpuslibrary.net/. It is not GPT
and is not sovereign. Ollama is the local base. JEEVES is the ethics/assistant
layer. **Lamb Lens first** — public Corpus posture; never the operator.

Hard refusals (in `azai/jeeves.py` SYSTEM):

- Never reveal operator account info, credentials, admin hashes, hidden routes
- Never advise actions that risk the corpus (wipe, score forge, quarantine bypass)
- **Cannot modify scores** — research assistant only; same rights as a normal user

Adaptive learning hook: pass optional retrieved public record titles/summaries
as `site_context` so answers improve as the library grows. Persist nothing secret.

Upload is **out of band**. Jeeves may *guide* upload but files still run full
SPRE×CLCE×PhysLing + Bayesian ingest — no score shortcut.

How the Corpus/Library calls AZAI/Jeeves:

1. Search the library: `GET https://www.azielcorpuslibrary.net/v1/search?q=`
2. POST those public titles/summaries to **local** AZAI (not hosted chat):

```bash
curl -s http://127.0.0.1:8860/v1/chat/completions \
  -H 'content-type: application/json' \
  -d '{
    "model": "local",
    "messages": [{"role": "user", "content": "What does the library say about Florence?"}],
    "site_context": [
      {"title": "Florence", "summary": "Public record summary"}
    ]
  }'
```

Read the contract: `GET http://127.0.0.1:8860/v1/jeeves` (local) or
`GET https://azai-download-tracker.vibelock.workers.dev/v1/jeeves` (hosted
card only). Hosted AZAI `/v1` does **not** run Jeeves chat.

## Example

```bash
curl -s -A 'Mozilla/5.0' https://azai-download-tracker.vibelock.workers.dev/v1/health
curl -s -A 'Mozilla/5.0' https://azai-download-tracker.vibelock.workers.dev/v1/skill
curl -s -A 'Mozilla/5.0' https://azai-download-tracker.vibelock.workers.dev/v1/jeeves
curl -s -A 'Mozilla/5.0' https://azai-download-tracker.vibelock.workers.dev/v1/mesh
```

## Local (after one-click install)

```bash
curl -fsSL https://azai-download-tracker.vibelock.workers.dev/install.sh | bash
azai ui
azai doctor
azai ollama
azai jeeves
```

The install path:

1. Downloads the counted tarball and `pip install -e .`
2. Runs `scripts/setup-ollama.sh` — installs or reuses Ollama, starts
   `ollama serve` if needed, pulls `llama3.2` (or `AZAI_OLLAMA_MODEL`)
3. If Ollama cannot be installed here, the script prints the exact steps
   and AZAI still runs with the JEEVES constitution stub

Then open http://127.0.0.1:8860 (loopback only). Default model is `local`
(Ollama + JEEVES / Ask Jeeves). Point other software at:

```bash
export OPENAI_BASE_URL=http://127.0.0.1:8860/v1
export OPENAI_API_KEY=dummy
```

Exact Ollama steps if doctor reports the base missing:

```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama serve
ollama pull llama3.2
azai doctor
```

Counted download (gzip HTTP 200, no 302): https://azai-download-tracker.vibelock.workers.dev/download?asset=azai-0.3.1.tar.gz
GitHub: https://github.com/AzielEliab/azai

## Catalog + local UI

Author: **Aziel Eliab**. Honest scope: true local AI on an Ollama base with
JEEVES (Ask Jeeves research assistant). Not a new foundation model. JEEVES
is not sovereign.

- Catalog product: https://aziel-runtime.vibelock.workers.dev/p/azai/
- Catalog OpenAPI: https://aziel-runtime.vibelock.workers.dev/openapi.json
- Catalog MCP: `POST https://aziel-runtime.vibelock.workers.dev/mcp`
- This Worker skill: `GET https://azai-download-tracker.vibelock.workers.dev/v1/skill`
- This Worker OpenAPI: https://azai-download-tracker.vibelock.workers.dev/openapi.json
- Ask Jeeves card: `GET https://azai-download-tracker.vibelock.workers.dev/v1/jeeves`
- Sample payload: `GET https://azai-download-tracker.vibelock.workers.dev/v1/example`
- Suite mesh: `GET https://azai-download-tracker.vibelock.workers.dev/v1/mesh` PROXY (default OFF)
- QNS-CD-1.0: hub cite / Worker mesh cross-map only (photon QNS1 packet transfer). Local qnsd: https://github.com/AzielEliab/qnm-node. Runtime cites: https://github.com/AzielEliab/aziel-runtime. Pair custody: https://github.com/AzielEliab/azinterface. Not a Softwares-tab product. Not a public qnsd proxy.

Local UI: **Ask Jeeves** research assistant, **Import JSON file** (`type=file`)
and **Export JSON**. Then `azai doctor`. Worker homepage Live Nodes strip polls `GET /v1/mesh` (default OFF). QNS-CD-1.0 is a cite on that payload, not a radio.

Public engines accept ChatGPT (GPT Actions / OpenAI), Grok (xAI), Venice, Claude (Anthropic), Cursor (MCP), Glama (MCP), Perplexity, Microsoft Copilot / Bing, Google Gemini / Vertex, Mistral, Meta AI, Apple Intelligence surfaces, Amazon Q tooling, DuckAssist, You.com, Cohere, and other MCP/OpenAPI-capable assistants. ChatGPT: GPT Actions. Grok: import catalog or Worker OpenAPI as a custom tool. Venice: HTTP tools. Claude, Cursor, Glama, and other MCP clients: catalog MCP.
