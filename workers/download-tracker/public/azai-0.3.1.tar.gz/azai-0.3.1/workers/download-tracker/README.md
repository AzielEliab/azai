# AZAI download tracker (Cloudflare Worker)

Counts GitHub-release downloads for AZAI across the canonical
repository, other branches, and forks. Forks are identified by GitHub
`owner/repo`.

Homepage is an **isolated counter**: the number is on the download
button. Nobody reports a download. The click is the count.

GET `/download` **serves** the tarball via `env.ASSETS.fetch`. It does
not 302 to GitHub. `Cache-Control: private, no-store`.

`totalKey()` = `azai|__total__`. PROJECT `azai`. Worker
`azai-download-tracker`. KV namespace `AZAI_DOWNLOADS` bound as
`DOWNLOADS`.

No secrets belong in this directory.

True local AI on an Ollama base with JEEVES. Not a new foundation model.
JEEVES is not sovereign. Hosted `/v1` is lamb-check ONLY (plus health/models).
Never a paid-key proxy. Forks are welcome and always allowed.

This worker is AZAI only. It is not mixed with AZ-OS, GodLock,
ForgeReceipts, The ARK, or any other product.

Isolated counter: Worker `azai-download-tracker`, project `azai`.

## Bindings

| Binding     | Type | Purpose |
|-------------|------|---------|
| `DOWNLOADS` | KV   | Counters keyed `project|owner|repo|branch|fork` |
| `AZIEL_RUNTIME` | service | Suite mesh PROXY to aziel-runtime (`/v1/mesh/*`) |

KV id in `wrangler.toml`: `155f641feb8244bea7fa245133128a32`. Binding name MUST stay `DOWNLOADS` (not
`AZAI_DOWNLOADS` — that is the Cloudflare namespace title).

## Routes

| Method | Path | Behavior |
|--------|------|----------|
| GET | `/` | Isolated homepage: live count on the download button |
| GET | `/download?repo=&tag=&asset=` | Increment KV, serve the asset from `ASSETS` |
| GET | `/count` | JSON `{project, views, downloads, total}` |
| GET | `/stats` | JSON totals plus per-repo and per-branch breakdown |
| POST | `/event` | A fork reports a download |

Tracked asset URL:

```
https://azai-download-tracker.vibelock.workers.dev/download?asset=azai-0.3.1.tar.gz
```

Rebuild the counted tarball from the repo root:

```
bash scripts/pack-tarball.sh
```

## CORS

All responses include `Access-Control-Allow-Origin: *`.

## AI runtime (`/v1`)

CORS `*`. `GET /v1/health`, `GET /v1/models`, `GET /v1/skill`, `GET /v1/jeeves`
(Ask Jeeves contract; not chat), `POST /v1/lamb-check` `{text}`,
`GET /openapi.json` (OpenAPI 3.1), `GET /ai`.
Routes under `/v1` **do not** increment download KV.
Lamb check is the JS port of `azai/lamb.py`. No provider proxy.

Help page: `/ai`. Combined catalog: https://aziel-runtime.vibelock.workers.dev/

POST `/v1/lamb-check` rejects bodies larger than 1 MiB (413). No API keys live in this Worker.

`/v1/mesh/*` PROXY to aziel-runtime suite mesh (`AZIEL_RUNTIME` / `https://aziel-runtime.vibelock.workers.dev`). Default OFF. QNM-BUILD-1.0 live|locked|isolated. QNS-CD-1.0 hub cite / Worker mesh cross-map (photon QNS1 packet transfer; local qnsd in [qnm-node](https://github.com/AzielEliab/qnm-node); runtime cites in [aziel-runtime](https://github.com/AzielEliab/aziel-runtime)). No Node Gate. No public qnsd proxy. No auto-heal. Not anonymity. Not a Softwares-tab product. Human UI Live Nodes strip polls `GET /v1/mesh`.

Verify: `curl -sS -A 'Mozilla/5.0' https://azai-download-tracker.vibelock.workers.dev/v1/mesh/status` returns MESH-OK style JSON with `enabled: false` by default and a `qns_cd` / `qns_cd_spec` cross-map (`QNS-CD-1.0`).

## Human / bot schema (`/stats` and `/count`)

Additive dual-count (Whitestone canary). Classification lives in `src/classify.js`
and response shaping in `src/stats-shape.js`.

Invariant: `views === views_human + views_bot` and
`downloads === downloads_human + downloads_bot`.

Legacy strategy (b): existing KV totals are never reset. Pre-split remainder
is shown as bot on read (`views_bot = views - views_human`). Author: Aziel Eliab only.

